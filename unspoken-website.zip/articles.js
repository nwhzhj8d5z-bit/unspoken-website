var ARTICLES = [
  {
    "slug": "the-waiting-room",
    "url": "article-the-waiting-room.html",
    "title": "The Waiting Room",
    "author": "Unspoken",
    "tag": "Time & Milestones",
    "tagColor": "purple",
    "teaser": "We keep waiting for the perfect moment to start living. But who decided what perfect is? On the script of perfection, handed to us by culture, family and gender, and what happens when we stop waiting for it.",
    "quote": "Perfection is not an objective destination. It is a moving target.",
    "image": "cover-the-waiting-room.png",
    "imageAlt": "A row of empty chairs under a wall clock in a quiet waiting room."
  },
  {
    "slug": "when-lights-are-on",
    "url": "article-when-lights-are-on.html",
    "title": "When Lights Are On, But Nobody's Home",
    "author": "Farida Younes",
    "tag": "Mind & Self",
    "tagColor": "green",
    "teaser": "On the dream that held you together, the adulthood nobody warned you about, and the question we're all too tired to ask: what does it actually mean to live?",
    "quote": "We're old enough to understand what we might lose, but young enough to still have so much to lose.",
    "image": "cover-lights-are-on.jpg",
    "imageAlt": "A lone figure standing on a skateboard in a pool of golden light on a crosswalk, while blurred silhouettes rush past in the dark."
  },
  {
    "slug": "entry-level-trap",
    "url": "article-entry-level-trap.html",
    "title": "The Entry-Level Trap",
    "author": "Mariam Eltelemy",
    "tag": "Work & Money",
    "tagColor": "purple",
    "teaser": "Why “entry-level” now means three years of experience nobody was willing to give you, and what that does to a generation waiting for its life to start.",
    "quote": "I didn't fail to knock. I knocked two hundred times.",
    "image": "cover-entry-level-trap.jpg",
    "imageAlt": "Overhead view of a sink full of mismatched coffee and tea cups in warm browns and ambers."
  }
];
